//
//  EndPoints.swift
//  IMDBClone
//
//  Created by Mohit Mehta on 14/06/22.
//

import Foundation

struct EndPoints{
    static let getApi = "https://www.omdbapi.com/?s=Batman&page=1&apikey=eeefc96f"
}
