//
//  IMDBCloneApp.swift
//  IMDBClone
//
//  Created by Mohit Mehta on 14/06/22.
//

import SwiftUI

@main
struct IMDBCloneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
